/*
 * Copyright 2022-2024 Open Text.
 *
 * The only warranties for products and services of Open Text and its
 * affiliates and licensors ("Open Text") are as may be set forth in the
 * express warranty statements accompanying such products and services.
 * Nothing herein should be construed as constituting an additional
 * warranty. Open Text shall not be liable for technical or editorial
 * errors or omissions contained herein. The information contained herein
 * is subject to change without notice.
 *
 * Except as specifically indicated otherwise, this document contains
 * confidential information and a valid license is required for possession,
 * use or copying. If this work is provided to the U.S. Government,
 * consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 * Computer Software Documentation, and Technical Data for Commercial Items
 * are licensed to the U.S. Government under vendor's standard commercial
 * license.
 */
using AgentApi.Client.Models;
using OpenText.Fusion.Agent.Common.Collections;
using OpenText.Fusion.AdapterSdk.Api;
using OpenText.Fusion.AdapterSdk.Engine;
using OpenText.Fusion.Agent.Processors.Common.REST;

namespace OpenText.Fusion.AdapterSdk.Samples.WorkerServiceExample
{
    // SDK can be extended with a custom handler of requests.
    public class CustomRequestHandler : IAdapterRequestHandler
    {
        private readonly ILogger<CustomRequestHandler> _logger;
        private readonly IRestUtil _restUtil;

        public CustomRequestHandler(ILogger<CustomRequestHandler> logger, IRestUtil restUtil)
        {
            _logger = logger;
            _restUtil = restUtil;
        }

        public bool CanHandle(IAdapterRequest adapterRequest)
        {
            return !adapterRequest.RequestType.ValueIn(AdapterRequestType.CaptureGetList, AdapterRequestType.CaptureWithList);
        }

        public async ValueTask ExecuteAsync(IAdapterRequest adapterRequest, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Handling {RequestId} of type {RequestType}", adapterRequest.RequestId, adapterRequest.RequestType);
            await Task.Delay(TimeSpan.FromSeconds(30), cancellationToken).ConfigureAwait(false);

            _restUtil.SendStatusUpdate(adapterRequest.RequestId,
                                       AgentRequestUpdate.RequestStatus.Finished,
                                       100,
                                       0,
                                       2,
                                       2,
                                       0,
                                       null,
                                       out var cancel);
        }
    }
}
