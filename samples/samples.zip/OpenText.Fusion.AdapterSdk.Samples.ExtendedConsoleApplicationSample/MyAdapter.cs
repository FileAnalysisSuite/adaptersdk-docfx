/*
 * Copyright 2022-2024 Open Text.
 *
 * The only warranties for products and services of Open Text and its
 * affiliates and licensors ("Open Text") are as may be set forth in the
 * express warranty statements accompanying such products and services.
 * Nothing herein should be construed as constituting an additional
 * warranty. Open Text shall not be liable for technical or editorial
 * errors or omissions contained herein. The information contained herein
 * is subject to change without notice.
 *
 * Except as specifically indicated otherwise, this document contains
 * confidential information and a valid license is required for possession,
 * use or copying. If this work is provided to the U.S. Government,
 * consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 * Computer Software Documentation, and Technical Data for Commercial Items
 * are licensed to the U.S. Government under vendor's standard commercial
 * license.
 */
using System.Diagnostics.CodeAnalysis;
using OpenText.Fusion.AdapterSdk.Api;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace OpenText.Fusion.AdapterSdk.Samples.ExtendedConsoleApplicationSample
{
    public class MyAdapter : IRepositoryAdapter
    {
        [SuppressMessage("ReSharper", 
                         "NotAccessedField.Local", 
                         Justification = "Component injected by DI for the sample purpose" )] 
        private readonly Component1 _component1;
        
        private readonly IOptionsMonitor<MyConfiguration> _configuration;
        private readonly ILogger<MyAdapter> _logger;

        public MyAdapter(Component1 component1, IOptionsMonitor<MyConfiguration> configuration, ILogger<MyAdapter> logger)
        {
            _component1 = component1;
            _configuration = configuration;
            _logger = logger;
        }

        public Task<IAdapterDescriptor> CreateDescriptorAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Creating the descriptor...");
            _logger.LogInformation("Adapter custom configuration: {@MyConfiguration}", _configuration);
            
            return Task.FromResult<IAdapterDescriptor>(new AdapterDescriptor("MyCustomAdapter",
                                                                             new List<RepositorySettingDefinition>
                                                                             {
                                                                                 new("Location", true),
                                                                                 new("UserName", true),
                                                                                 new("Password", true)
                                                                             }));
        }

        public async Task RetrieveFileListAsync(RetrieveFileListRequest request, IFileListResultsHandler handler, CancellationToken cancellationToken)
        {
            // Get the repository option provided in UI, the location to scan
            var location = request.RepositoryProperties.RepositoryOptions.GetOption("Location");
            var userName = request.RepositoryProperties.RepositoryOptions.GetOption("UserName");
            var password = request.RepositoryProperties.RepositoryOptions.GetOption("Password");

            try
            {
                // Perform some operation, like a login
                LogIn(userName, password);
            }
            catch (Exception ex)
            {
                await handler.RegisterFailureAsync(new FailureDetails("Failed to log in to the repository", ex), cancellationToken);

                return;
            }

            if (location is null)
            {
                await handler.RegisterFailureAsync(new FailureDetails("Location cannot be null"), cancellationToken);;
                return;
            }

            var directoryInfo = new DirectoryInfo(location);

            try
            {
                foreach (var file in directoryInfo.EnumerateFiles("*", SearchOption.AllDirectories))
                {
                    cancellationToken.ThrowIfCancellationRequested();

                    await handler.QueueFileAsync(new FileMetadata(file.Name, file.FullName)
                                                 {
                                                     ModifiedTime = file.LastWriteTimeUtc,
                                                     AccessedTime = file.LastAccessTimeUtc,
                                                     CreatedTime = file.CreationTimeUtc
                                                 },
                                                 file.DirectoryName ?? string.Empty,
                                                 cancellationToken);
                }
            }
            catch (Exception ex)
            {
                await handler.RegisterFailureAsync(directoryInfo.FullName, new FailureDetails(ex.Message, ex), cancellationToken);
            }
        }

        public async Task RetrieveFilesDataAsync(RepositoryFilesRequest request, IFileDataResultsHandler handler, CancellationToken cancellationToken)
        {
            foreach (var repositoryItem in request.Files)
            {
                cancellationToken.ThrowIfCancellationRequested();
                
                repositoryItem.Metadata.AdditionalMetadata.Add("custom_property", new []{"123"});
                await handler.QueueFileAsync(repositoryItem.FileId,() =>
                                                              {
                                                                  var file = new FileInfo(repositoryItem.Metadata.FileLocation);

                                                                  return file.OpenRead();
                                                              },
                                             repositoryItem.Metadata,
                                             cancellationToken);
            }
        }

        private void LogIn(string? userName, string? password)
        {
            // perform login...
            _logger.LogInformation("Logging in the user (for testing purposes, not production): {UserName} / {DecryptedPassword}", userName, password);
        }
    }
}
