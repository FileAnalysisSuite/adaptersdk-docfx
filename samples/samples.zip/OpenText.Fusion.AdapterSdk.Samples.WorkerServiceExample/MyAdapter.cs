/*
 * Copyright 2022-2024 Open Text.
 *
 * The only warranties for products and services of Open Text and its
 * affiliates and licensors ("Open Text") are as may be set forth in the
 * express warranty statements accompanying such products and services.
 * Nothing herein should be construed as constituting an additional
 * warranty. Open Text shall not be liable for technical or editorial
 * errors or omissions contained herein. The information contained herein
 * is subject to change without notice.
 *
 * Except as specifically indicated otherwise, this document contains
 * confidential information and a valid license is required for possession,
 * use or copying. If this work is provided to the U.S. Government,
 * consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 * Computer Software Documentation, and Technical Data for Commercial Items
 * are licensed to the U.S. Government under vendor's standard commercial
 * license.
 */
using OpenText.Fusion.AdapterSdk.Api;
using Microsoft.Extensions.Options;

namespace OpenText.Fusion.AdapterSdk.Samples.WorkerServiceExample
{
    public class MyAdapter : IRepositoryAdapter
    {
        private readonly ILogger<MyAdapter> _logger;
        private readonly IOptions<MyAdapterConfiguration> _configuration;

        public MyAdapter(ILogger<MyAdapter> logger, IOptions<MyAdapterConfiguration> configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        public Task<IAdapterDescriptor> CreateDescriptorAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult<IAdapterDescriptor>(new AdapterDescriptor(_configuration.Value.AdapterType,
                                                                             new List<RepositorySettingDefinition>
                                                                             {
                                                                                 new("Location", true),
                                                                                 new("UserName", true),
                                                                                 new("Password", true)
                                                                             }));
        }

        public async Task RetrieveFileListAsync(RetrieveFileListRequest request, IFileListResultsHandler handler, CancellationToken cancellationToken)
        {
            
            // Get the repository option provided in UI, the location to scan
            var location = request.RepositoryProperties.RepositoryOptions.GetOption("Location");
            var userName = request.RepositoryProperties.RepositoryOptions.GetOption("UserName");
            var password = request.RepositoryProperties.RepositoryOptions.GetOption("Password");
            _logger.LogInformation("Starting processing of RetrieveFileList request using {Location}, {UserName}", location, userName);
            _logger.LogDebug("RetrieveFileList request details: {@RetrieveFileListRequest}", request);
            try
            {
                // Perform some operation, like a login
                LogIn(userName, password);
            }
            catch (Exception ex)
            {
                await handler.RegisterFailureAsync(new FailureDetails("Failed to log in to the repository", ex), cancellationToken);
                return;
            }

            if (location is null)
            {
                await handler.RegisterFailureAsync(new FailureDetails("Location cannot be null"), cancellationToken);;
                return;
            }

            var directoryInfo = new DirectoryInfo(location);
            await ProcessDirectoryAsync(directoryInfo, handler, cancellationToken);

        }

        private async Task ProcessDirectoryAsync(DirectoryInfo directory, IFileListResultsHandler handler, CancellationToken cancellationToken)
        {
            try
            {
                foreach (var file in directory.EnumerateFiles("*", SearchOption.TopDirectoryOnly))
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    await handler.QueueFileAsync(new FileMetadata(file.Name, file.FullName)
                                                 {
                                                     ModifiedTime = file.LastWriteTimeUtc,
                                                     AccessedTime = file.LastAccessTimeUtc,
                                                     CreatedTime = file.CreationTimeUtc
                                                 },
                                                 file.DirectoryName ?? string.Empty,
                                                 cancellationToken);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to process directory {Directory}", directory);
                await handler.RegisterFailureAsync(directory.FullName, new FailureDetails($"Failed to process directory {directory}", ex), cancellationToken);
            }

            try
            {
                var directories = directory.EnumerateDirectories();
                foreach (var subDirectory in directories)
                {
                    await ProcessDirectoryAsync(subDirectory, handler, cancellationToken);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to process subdirectories for {Directory}", directory);
                await handler.RegisterFailureAsync(directory.FullName, new FailureDetails($"Failed to process directory {directory}", ex), cancellationToken);
            }
        }

        public async Task RetrieveFilesDataAsync(RepositoryFilesRequest request, IFileDataResultsHandler handler, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Starting processing of RetrieveFilesData request, number of items: {NumItems}", request.Files.Count());

            foreach (var repositoryItem in request.Files)
            {
                if (repositoryItem.Metadata.FileLocation == null)
                {
                    throw new InvalidOperationException("Repository item metadata ItemLocation property was null!");
                }

                await handler.QueueFileAsync(repositoryItem.FileId,() =>
                                                              {
                                                                  var file = new FileInfo(repositoryItem.Metadata.FileLocation);

                                                                  return file.OpenRead();
                                                              },
                                             repositoryItem.Metadata,
                                             cancellationToken);
            }
        }

        private void LogIn(string? userName, string? password)
        {
            // perform login...
            _logger.LogInformation("Logging in the user (for testing purposes, not production): {UserName} / {DecryptedPassword}", userName, password);
        }

    }
}
