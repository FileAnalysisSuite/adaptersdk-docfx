/*
 * Copyright 2022-2024 Open Text.
 *
 * The only warranties for products and services of Open Text and its
 * affiliates and licensors ("Open Text") are as may be set forth in the
 * express warranty statements accompanying such products and services.
 * Nothing herein should be construed as constituting an additional
 * warranty. Open Text shall not be liable for technical or editorial
 * errors or omissions contained herein. The information contained herein
 * is subject to change without notice.
 *
 * Except as specifically indicated otherwise, this document contains
 * confidential information and a valid license is required for possession,
 * use or copying. If this work is provided to the U.S. Government,
 * consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 * Computer Software Documentation, and Technical Data for Commercial Items
 * are licensed to the U.S. Government under vendor's standard commercial
 * license.
 */
// See https://aka.ms/new-console-template for more information

using Autofac;
using Autofac.Extensions.DependencyInjection;
using OpenText.Fusion.AdapterSdk.Engine.Runtime;
using OpenText.Fusion.AdapterSdk.Samples.ExtendedConsoleApplicationSample;
using Microsoft.Extensions.DependencyInjection;
// Attach to Ctrl+C and cancel processing and shut down the agent when pressed
using var cancellationSource = new CancellationTokenSource();
Console.CancelKeyPress += (_, _) => cancellationSource.Cancel();
var engineFactory = ProcessingEngineFactoryConfigurator.Current.BuildConfigured<MyAdapter, ContainerBuilder>("MyAdapter",
                                                                                                             // Use Autofac as the dependency injection container
                                                                                                             new AutofacServiceProviderFactory(),
                                                                                                             (builder, configuration) =>
                                                                                                             {
                                                                                                                 // Configure custom types
                                                                                                                 builder.RegisterType<Service1>()
                                                                                                                        .AsSelf()
                                                                                                                        .SingleInstance();
                                                                                                                 builder.RegisterType<Component1>()
                                                                                                                        .PropertiesAutowired()
                                                                                                                        .AsSelf();
                                                                                                                 builder.RegisterType<DefaultService2>()
                                                                                                                        .As<IService2>();
                                                                                                             },
                                                                                                             (services, configuration) =>
                                                                                                             {
                                                                                                                 // Additional configuration of dependency injection
                                                                                                                 // services.AddSingleton<...>()

                                                                                                                 // Use Options pattern for configuration
                                                                                                                 // https://docs.microsoft.com/en-us/dotnet/core/extensions/options
                                                                                                                 var configSection =
                                                                                                                     configuration
                                                                                                                         .GetSection(nameof(MyConfiguration));
                                                                                                                 services
                                                                                                                     .Configure<MyConfiguration>(configSection);
                                                                                                             },
                                                                                                             cancellationSource.Token);


// Create the processing engine
var processingEngine = engineFactory.CreateEngine();



// StartAsync the engine and wait until it's shut down due to a problem or Ctrl+C pressed
await processingEngine.ExecuteAsync(cancellationSource.Token);
