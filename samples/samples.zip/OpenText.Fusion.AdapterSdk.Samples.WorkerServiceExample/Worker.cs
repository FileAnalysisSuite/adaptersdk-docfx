/*
 * Copyright 2022-2024 Open Text.
 *
 * The only warranties for products and services of Open Text and its
 * affiliates and licensors ("Open Text") are as may be set forth in the
 * express warranty statements accompanying such products and services.
 * Nothing herein should be construed as constituting an additional
 * warranty. Open Text shall not be liable for technical or editorial
 * errors or omissions contained herein. The information contained herein
 * is subject to change without notice.
 *
 * Except as specifically indicated otherwise, this document contains
 * confidential information and a valid license is required for possession,
 * use or copying. If this work is provided to the U.S. Government,
 * consistent with FAR 12.211 and 12.212, Commercial Computer Software,
 * Computer Software Documentation, and Technical Data for Commercial Items
 * are licensed to the U.S. Government under vendor's standard commercial
 * license.
 */
using OpenText.Fusion.AdapterSdk.Api;

namespace OpenText.Fusion.AdapterSdk.Samples.WorkerServiceExample
{
    public class Worker : BackgroundService
    {
        private readonly IProcessingEngineFactory _engineFactory;
        private readonly ILogger<Worker> _logger;

        public Worker(ILogger<Worker> logger, IProcessingEngineFactory engineFactory)
        {
            _logger = logger;
            _engineFactory = engineFactory;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {

            stoppingToken.Register(() => _logger.LogInformation("Worker - cancellation requested, service will stop"));
            _logger.LogInformation("Starting Worker Service...");
            try
            {
                var processingEngine = _engineFactory.CreateEngine();
            
                await processingEngine.ExecuteAsync(stoppingToken).ConfigureAwait(false);
            
                _logger.LogInformation("Stopping worker service");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception caught during execution");
                throw;
            }
        }
    }
}
